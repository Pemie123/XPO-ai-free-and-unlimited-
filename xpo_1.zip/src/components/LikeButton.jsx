import React, { useState, useEffect } from "react";
import { Heart } from "lucide-react";
import { base44 } from "@/api/base44Client";

const STORAGE_KEY = "freeform_liked";

function getLikedIds() {
  try { return JSON.parse(localStorage.getItem(STORAGE_KEY) || "[]"); } catch { return []; }
}
function saveLikedIds(ids) {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(ids));
}

export default function LikeButton({ item, entityName = "SharedMedia" }) {
  const [liked, setLiked] = useState(false);
  const [count, setCount] = useState(item.likes || 0);
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    setLiked(getLikedIds().includes(item.id));
    setCount(item.likes || 0);
  }, [item.id, item.likes]);

  const toggle = async () => {
    if (busy) return;
    setBusy(true);
    const alreadyLiked = getLikedIds().includes(item.id);
    const newCount = Math.max(0, count + (alreadyLiked ? -1 : 1));
    const prevCount = count;
    setCount(newCount);
    setLiked(!alreadyLiked);
    try {
      await base44.entities[entityName].update(item.id, { likes: newCount });
      const ids = getLikedIds();
      if (alreadyLiked) saveLikedIds(ids.filter(id => id !== item.id));
      else saveLikedIds([...ids, item.id]);
    } catch (e) {
      setCount(prevCount);
      setLiked(alreadyLiked);
    }
    setBusy(false);
  };

  return (
    <button
      onClick={toggle}
      disabled={busy}
      className="flex flex-col items-center gap-1 group select-none"
    >
      <div className="w-11 h-11 rounded-full bg-black/40 backdrop-blur-sm flex items-center justify-center border border-white/10 group-hover:bg-black/60 transition">
        <Heart className={`w-6 h-6 transition drop-shadow-lg ${liked ? "fill-rose-500 text-rose-500 scale-110" : "text-white/80"}`} />
      </div>
      <span className="text-white text-xs font-medium drop-shadow-lg">{count}</span>
    </button>
  );
}