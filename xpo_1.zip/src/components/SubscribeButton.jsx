import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { UserPlus, UserCheck } from "lucide-react";

export default function SubscribeButton({ creatorUsername }) {
  const [subscribed, setSubscribed] = useState(false);
  const [subId, setSubId] = useState(null);
  const [loading, setLoading] = useState(true);
  const [userId, setUserId] = useState(null);

  useEffect(() => {
    if (!creatorUsername) { setLoading(false); return; }
    base44.auth.me()
      .then((me) => {
        if (!me) { setLoading(false); return; }
        setUserId(me.id);
        return base44.entities.Subscription.filter(
          { creator_username: creatorUsername, created_by_id: me.id },
          null,
          1
        );
      })
      .then((subs) => {
        if (subs) {
          setSubscribed(subs.length > 0);
          setSubId(subs[0]?.id);
        }
      })
      .catch(() => {})
      .finally(() => setLoading(false));
  }, [creatorUsername]);

  const toggle = async () => {
    if (loading || !userId) return;
    setLoading(true);
    try {
      if (subscribed && subId) {
        await base44.entities.Subscription.delete(subId);
        setSubscribed(false);
        setSubId(null);
      } else {
        const sub = await base44.entities.Subscription.create({ creator_username: creatorUsername });
        setSubscribed(true);
        setSubId(sub.id);
      }
    } catch (e) {
    } finally {
      setLoading(false);
    }
  };

  if (!userId && !loading) return null;

  return (
    <button
      onClick={toggle}
      disabled={loading}
      className={`inline-flex items-center gap-1 px-3 py-1.5 rounded-full text-xs font-medium transition ${
        subscribed
          ? "bg-white/10 text-white/60 border border-white/10"
          : "bg-gradient-to-r from-violet-600 to-fuchsia-600 text-white"
      }`}
    >
      {subscribed ? <UserCheck className="w-3 h-3" /> : <UserPlus className="w-3 h-3" />}
      {subscribed ? "Subscribed" : "Subscribe"}
    </button>
  );
}