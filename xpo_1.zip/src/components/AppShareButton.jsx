import React, { useState } from "react";
import { Share2, Loader2, Copy, Link as LinkIcon } from "lucide-react";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";

export default function AppShareButton({ appType, prompt, title, code, disabled }) {
  const [state, setState] = useState("idle");
  const [shareUrl, setShareUrl] = useState("");

  const handleShare = async () => {
    setState("sharing");
    try {
      let username = "";
      try { const me = await base44.auth.me(); username = me?.username || ""; } catch {}
      const record = await base44.entities.SharedApp.create({
        app_type: appType,
        prompt: prompt || title,
        title: title || prompt,
        content: code,
        username,
      });
      const link = `${window.location.origin}/a/${record.id}`;
      setShareUrl(link);
      try { await navigator.clipboard.writeText(link); } catch {}
      setState("done");
    } catch (e) {
      console.error(e);
      setState("error");
    }
  };

  if (state === "done") {
    return (
      <div className="flex items-center gap-2">
        <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-md bg-emerald-500/10 border border-emerald-500/20 text-emerald-300 text-xs min-w-0">
          <LinkIcon className="w-3.5 h-3.5 shrink-0" />
          <span className="truncate">Link copied!</span>
        </div>
        <Button variant="secondary" size="icon" onClick={() => navigator.clipboard.writeText(shareUrl)} className="bg-white/5 border border-white/10 h-8 w-8">
          <Copy className="w-3.5 h-3.5" />
        </Button>
      </div>
    );
  }

  return (
    <Button variant="secondary" size="sm" onClick={handleShare} disabled={disabled || state === "sharing"} className="bg-white/5 border border-white/10 hover:bg-white/10 text-white">
      {state === "sharing" ? <Loader2 className="w-4 h-4 mr-1.5 animate-spin" /> : <Share2 className="w-4 h-4 mr-1.5" />}
      {state === "sharing" ? "Publishing…" : state === "error" ? "Failed — retry" : "Share Online"}
    </Button>
  );
}