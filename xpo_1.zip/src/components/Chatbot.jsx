import React from "react";
import { Link } from "react-router-dom";
import { MessageCircle } from "lucide-react";

export default function Chatbot() {
  return (
    <Link
      to="/chatbot"
      className="fixed top-4 left-4 z-50 flex items-center gap-2 px-4 py-2.5 rounded-full bg-gradient-to-r from-violet-600 to-fuchsia-600 text-white text-sm font-semibold shadow-lg shadow-fuchsia-500/20 hover:scale-105 transition"
    >
      <MessageCircle className="w-4 h-4" />
      CHATBOT
    </Link>
  );
}