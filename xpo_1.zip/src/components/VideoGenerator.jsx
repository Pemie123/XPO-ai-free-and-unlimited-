import React, { useState, useRef } from "react";
import { Film, Loader2, Download, Sparkles } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import ShareButton from "@/components/ShareButton";

const MODELS = [
  { value: "flux", label: "Flux" },
  { value: "turbo", label: "Turbo (Fast)" },
];

const MOTIONS = [
  { value: "kenburns", label: "Ken Burns (Zoom + Pan)" },
  { value: "zoomin", label: "Zoom In" },
  { value: "zoomout", label: "Zoom Out" },
  { value: "panleft", label: "Pan Left" },
  { value: "panright", label: "Pan Right" },
];

const RATIOS = [
  { value: "landscape", label: "Landscape (16:9)", w: 1024, h: 576 },
  { value: "square", label: "Square", w: 768, h: 768 },
  { value: "portrait", label: "Portrait (9:16)", w: 576, h: 1024 },
];

const FPS = 30;
const DURATIONS = [3, 4, 5, 6, 7, 8];

function buildUrl(prompt, model, ratio, seed) {
  return `https://image.pollinations.ai/prompt/${encodeURIComponent(prompt)}?width=${ratio.w}&height=${ratio.h}&seed=${seed}&model=${model}&nologo=true`;
}

export default function VideoGenerator({ initialPrompt }) {
  const [prompt, setPrompt] = useState(initialPrompt || "");
  const [model, setModel] = useState("flux");
  const [ratioKey, setRatioKey] = useState("landscape");
  const [motion, setMotion] = useState("kenburns");
  const [duration, setDuration] = useState(5);
  const [status, setStatus] = useState("idle");
  const [videoUrl, setVideoUrl] = useState(null);
  const [videoBlob, setVideoBlob] = useState(null);
  const [progress, setProgress] = useState(0);
  const canvasRef = useRef(null);

  const ratio = RATIOS.find((r) => r.value === ratioKey);

  const handleGenerate = async () => {
    if (!prompt.trim()) return;
    setStatus("generating");
    setProgress(0);
    setVideoUrl(null);
    setVideoBlob(null);

    const seed = Math.floor(Math.random() * 1000000);
    const imgUrl = buildUrl(`${prompt.trim()}, cinematic, highly detailed`, model, ratio, seed);

    let img;
    try {
      img = await new Promise((resolve, reject) => {
        const im = new Image();
        im.crossOrigin = "anonymous";
        im.onload = () => resolve(im);
        im.onerror = reject;
        im.src = imgUrl;
      });
    } catch (e) {
      setStatus("idle");
      return;
    }

    setStatus("composing");
    await composeVideo(img);
  };

  const composeVideo = (img) => {
    return new Promise((resolve) => {
      const canvas = canvasRef.current;
      canvas.width = ratio.w;
      canvas.height = ratio.h;
      const ctx = canvas.getContext("2d");
      const cw = canvas.width;
      const ch = canvas.height;

      const stream = canvas.captureStream(FPS);
      let recorder;
      try {
        recorder = new MediaRecorder(stream, { mimeType: "video/webm;codecs=vp9" });
      } catch {
        recorder = new MediaRecorder(stream, { mimeType: "video/webm" });
      }
      const chunks = [];
      recorder.ondataavailable = (e) => e.data.size > 0 && chunks.push(e.data);
      recorder.onstop = () => {
        const blob = new Blob(chunks, { type: "video/webm" });
        setVideoBlob(blob);
        setVideoUrl(URL.createObjectURL(blob));
        setStatus("done");
        resolve();
      };

      const maxScale = 1.3;
      const overscan = maxScale - 1;

      // Cover-fit the image to the canvas
      const imgRatio = img.width / img.height;
      const canvasRatio = cw / ch;

      recorder.start();
      const startTime = performance.now();

      const drawFrame = () => {
        const elapsed = (performance.now() - startTime) / 1000;
        const t = Math.min(elapsed / duration, 1);

        let scale, panX, panY;
        switch (motion) {
          case "zoomin":
            scale = 1 + t * overscan;
            panX = 0.5; panY = 0.5;
            break;
          case "zoomout":
            scale = maxScale - t * overscan;
            panX = 0.5; panY = 0.5;
            break;
          case "panleft":
            scale = maxScale;
            panX = t; panY = 0.5;
            break;
          case "panright":
            scale = maxScale;
            panX = 1 - t; panY = 0.5;
            break;
          case "kenburns":
          default:
            scale = 1 + t * overscan;
            panX = 0.5 + (t - 0.5) * 0.6;
            panY = 0.5;
            break;
        }

        let drawW, drawH;
        if (imgRatio > canvasRatio) {
          drawH = ch * scale;
          drawW = drawH * imgRatio;
        } else {
          drawW = cw * scale;
          drawH = drawW / imgRatio;
        }
        const offsetX = -(drawW - cw) * panX;
        const offsetY = -(drawH - ch) * panY;

        ctx.fillStyle = "#000";
        ctx.fillRect(0, 0, cw, ch);
        ctx.drawImage(img, offsetX, offsetY, drawW, drawH);

        setProgress(Math.round(t * 100));

        if (t >= 1) {
          setTimeout(() => recorder.stop(), 200);
          return;
        }
        requestAnimationFrame(drawFrame);
      };
      drawFrame();
    });
  };

  const handleDownload = () => {
    if (!videoUrl) return;
    const a = document.createElement("a");
    a.href = videoUrl;
    a.download = "freeform-video.webm";
    a.click();
  };

  const busy = status === "generating" || status === "composing";

  return (
    <div className="grid lg:grid-cols-[380px_1fr] gap-6">
      <div className="space-y-5 rounded-2xl bg-white/[0.04] border border-white/10 p-5 backdrop-blur-sm">
        <div className="space-y-2">
          <Label className="text-white/70 text-xs uppercase tracking-wider">Prompt</Label>
          <Textarea
            value={prompt}
            onChange={(e) => setPrompt(e.target.value)}
            placeholder="Describe a scene — we'll generate an AI image and animate it into a cinematic video…"
            className="bg-white/5 border-white/10 text-white placeholder:text-white/30 resize-none min-h-[110px]"
          />
        </div>

        <div className="grid grid-cols-2 gap-3">
          <div className="space-y-1.5">
            <Label className="text-white/70 text-xs uppercase tracking-wider">Model</Label>
            <Select value={model} onValueChange={setModel}>
              <SelectTrigger className="bg-white/5 border-white/10 text-white"><SelectValue /></SelectTrigger>
              <SelectContent>
                {MODELS.map((m) => <SelectItem key={m.value} value={m.value}>{m.label}</SelectItem>)}
              </SelectContent>
            </Select>
          </div>
          <div className="space-y-1.5">
            <Label className="text-white/70 text-xs uppercase tracking-wider">Ratio</Label>
            <Select value={ratioKey} onValueChange={setRatioKey}>
              <SelectTrigger className="bg-white/5 border-white/10 text-white"><SelectValue /></SelectTrigger>
              <SelectContent>
                {RATIOS.map((r) => <SelectItem key={r.value} value={r.value}>{r.label}</SelectItem>)}
              </SelectContent>
            </Select>
          </div>
        </div>

        <div className="space-y-1.5">
          <Label className="text-white/70 text-xs uppercase tracking-wider">Camera Motion</Label>
          <Select value={motion} onValueChange={setMotion}>
            <SelectTrigger className="bg-white/5 border-white/10 text-white"><SelectValue /></SelectTrigger>
            <SelectContent>
              {MOTIONS.map((m) => <SelectItem key={m.value} value={m.value}>{m.label}</SelectItem>)}
            </SelectContent>
          </Select>
        </div>

        <div className="space-y-1.5">
          <Label className="text-white/70 text-xs uppercase tracking-wider">Duration</Label>
          <Select value={String(duration)} onValueChange={(v) => setDuration(Number(v))}>
            <SelectTrigger className="bg-white/5 border-white/10 text-white"><SelectValue /></SelectTrigger>
            <SelectContent>
              {DURATIONS.map((d) => <SelectItem key={d} value={String(d)}>{d} seconds</SelectItem>)}
            </SelectContent>
          </Select>
        </div>

        <Button
          onClick={handleGenerate}
          disabled={!prompt.trim() || busy}
          className="w-full bg-gradient-to-r from-violet-500 to-fuchsia-500 hover:from-violet-400 hover:to-fuchsia-400 text-white border-0 h-11"
        >
          {busy ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : <Sparkles className="w-4 h-4 mr-2" />}
          {status === "generating" ? "Generating image…" : status === "composing" ? "Animating video…" : "Generate Video"}
        </Button>
        <p className="text-[11px] text-white/30 text-center -mt-2">Image-to-video animation · 100% free</p>
      </div>

      <div className="rounded-2xl bg-white/[0.02] border border-white/10 p-4 min-h-[320px] flex items-center justify-center">
        <canvas ref={canvasRef} className="hidden" />
        {status === "idle" && (
          <div className="text-center text-white/30 py-20">
            <Film className="w-12 h-12 mx-auto mb-3 opacity-40" />
            <p className="text-sm">Your generated video will appear here</p>
            <p className="text-xs text-white/20 mt-1">An AI image is generated and brought to life with cinematic camera motion</p>
          </div>
        )}
        {status === "generating" && (
          <div className="text-center text-white/50 py-20">
            <Loader2 className="w-10 h-10 mx-auto mb-4 text-violet-400 animate-spin" />
            <p className="text-sm">Generating AI image…</p>
          </div>
        )}
        {status === "composing" && (
          <div className="text-center text-white/50 py-20">
            <Loader2 className="w-10 h-10 mx-auto mb-4 text-fuchsia-400 animate-spin" />
            <p className="text-sm">Animating into video… {progress}%</p>
          </div>
        )}
        {status === "done" && videoUrl && (
          <div className="w-full space-y-3">
            <video src={videoUrl} controls autoPlay loop className="w-full rounded-xl border border-white/10 bg-black" style={{ aspectRatio: `${ratio.w} / ${ratio.h}` }} />
            <div className="flex items-center justify-between gap-2">
              <p className="text-xs text-white/40 truncate flex-1">{prompt}</p>
              <div className="flex items-center gap-2">
                <ShareButton mediaType="video" prompt={prompt} blob={videoBlob} width={ratio.w} height={ratio.h} model={model} />
                <Button variant="secondary" size="sm" onClick={handleDownload} className="bg-white/5 border border-white/10 hover:bg-white/10 text-white">
                  <Download className="w-4 h-4 mr-1.5" />Download
                </Button>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}