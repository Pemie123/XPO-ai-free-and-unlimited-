import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { User, Loader2 } from "lucide-react";

export default function UsernamePrompt() {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);
  const [username, setUsername] = useState("");
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState("");

  useEffect(() => {
    base44.auth.me()
      .then((u) => setUser(u))
      .catch(() => setUser(null))
      .finally(() => setLoading(false));
  }, []);

  if (loading || !user || user.username) return null;

  const handleSave = async () => {
    const name = username.trim();
    if (name.length < 3) {
      setError("Username must be at least 3 characters");
      return;
    }
    setSaving(true);
    setError("");
    try {
      await base44.auth.updateMe({ username: name });
      setUser({ ...user, username: name });
    } catch (e) {
      setError("Failed to save username");
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center bg-black/80 backdrop-blur-sm p-4">
      <div className="w-full max-w-sm rounded-2xl bg-[#0f0a1c] border border-white/15 p-6 text-center">
        <div className="w-14 h-14 rounded-full bg-gradient-to-br from-violet-600 to-fuchsia-600 flex items-center justify-center mx-auto mb-4">
          <User className="w-7 h-7 text-white" />
        </div>
        <h2 className="text-white text-lg font-bold mb-1">Pick a username</h2>
        <p className="text-white/40 text-sm mb-5">This name appears on your shared creations.</p>
        <input
          value={username}
          onChange={(e) => setUsername(e.target.value)}
          onKeyDown={(e) => e.key === "Enter" && handleSave()}
          placeholder="e.g. neon_creator"
          maxLength={20}
          className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-white text-center text-sm placeholder:text-white/30 focus:outline-none focus:ring-2 focus:ring-fuchsia-500/50 mb-3"
          autoFocus
        />
        {error && <p className="text-red-400 text-xs mb-3">{error}</p>}
        <button
          onClick={handleSave}
          disabled={saving}
          className="w-full bg-gradient-to-r from-violet-600 to-fuchsia-600 text-white font-semibold py-3 rounded-xl hover:opacity-90 transition disabled:opacity-50"
        >
          {saving ? <Loader2 className="w-4 h-4 animate-spin mx-auto" /> : "Continue"}
        </button>
      </div>
    </div>
  );
}