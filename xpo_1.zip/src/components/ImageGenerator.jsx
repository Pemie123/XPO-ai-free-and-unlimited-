import React, { useState } from "react";
import { Download, Shuffle, Sparkles, ImageIcon, Loader2 } from "lucide-react";
import ShareButton from "@/components/ShareButton";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

const MODELS = [
  { value: "flux", label: "Flux" },
  { value: "turbo", label: "Turbo (Fast)" },
  { value: "flux-realism", label: "Realism" },
  { value: "flux-anime", label: "Anime" },
  { value: "flux-3d", label: "3D" },
  { value: "any-dark", label: "Dark" },
];

const RATIOS = [
  { value: "square", label: "Square", w: 1024, h: 1024 },
  { value: "portrait", label: "Portrait", w: 768, h: 1024 },
  { value: "landscape", label: "Landscape", w: 1024, h: 768 },
  { value: "wide", label: "Wide", w: 1280, h: 720 },
];

const SUGGESTIONS = [
  "A neon-lit cyberpunk city at night, rain reflections",
  "A serene Japanese garden with cherry blossoms at sunset",
  "An astronaut floating in a nebula of glowing colors",
  "A cozy cabin in a snowy forest, warm window light",
  "A surreal floating island with waterfalls into the clouds",
];

function buildUrl(prompt, model, ratio, seed) {
  const enc = encodeURIComponent(prompt);
  return `https://image.pollinations.ai/prompt/${enc}?width=${ratio.w}&height=${ratio.h}&seed=${seed}&model=${model}&nologo=true`;
}

export default function ImageGenerator({ initialPrompt }) {
  const [prompt, setPrompt] = useState(initialPrompt || "");
  const [model, setModel] = useState("flux");
  const [ratioKey, setRatioKey] = useState("square");
  const [seed, setSeed] = useState(Math.floor(Math.random() * 1000000));
  const [generating, setGenerating] = useState(false);
  const [current, setCurrent] = useState(null);
  const [gallery, setGallery] = useState([]);
  const [downloading, setDownloading] = useState(false);

  const ratio = RATIOS.find((r) => r.value === ratioKey);

  const handleGenerate = () => {
    if (!prompt.trim()) return;
    const url = buildUrl(prompt.trim(), model, ratio, seed);
    setCurrent({ url, prompt: prompt.trim(), model, ratio, seed });
    setGenerating(true);
  };

  const handleLoaded = () => {
    setGenerating(false);
    if (current) {
      setGallery((prev) => {
        if (prev.some((g) => g.url === current.url)) return prev;
        return [current, ...prev].slice(0, 24);
      });
    }
  };

  const handleDownload = async () => {
    if (!current) return;
    setDownloading(true);
    try {
      const res = await fetch(current.url);
      const blob = await res.blob();
      const a = document.createElement("a");
      a.href = URL.createObjectURL(blob);
      a.download = `freeform-${current.seed}.png`;
      a.click();
      URL.revokeObjectURL(a.href);
    } finally {
      setDownloading(false);
    }
  };

  const randomSeed = () => setSeed(Math.floor(Math.random() * 1000000));

  return (
    <div className="grid lg:grid-cols-[380px_1fr] gap-6">
      {/* Controls */}
      <div className="space-y-5 rounded-2xl bg-white/[0.04] border border-white/10 p-5 backdrop-blur-sm">
        <div className="space-y-2">
          <Label className="text-white/70 text-xs uppercase tracking-wider">Prompt</Label>
          <Textarea
            value={prompt}
            onChange={(e) => setPrompt(e.target.value)}
            placeholder="Describe the image you want to create…"
            className="bg-white/5 border-white/10 text-white placeholder:text-white/30 resize-none min-h-[110px]"
          />
        </div>

        <div className="flex flex-wrap gap-1.5">
          {SUGGESTIONS.map((s) => (
            <button
              key={s}
              onClick={() => setPrompt(s)}
              className="text-[11px] px-2.5 py-1 rounded-full bg-white/5 hover:bg-white/10 text-white/50 hover:text-white/80 transition border border-white/5"
            >
              {s.split(" ").slice(0, 3).join(" ")}…
            </button>
          ))}
        </div>

        <div className="grid grid-cols-2 gap-3">
          <div className="space-y-1.5">
            <Label className="text-white/70 text-xs uppercase tracking-wider">Model</Label>
            <Select value={model} onValueChange={setModel}>
              <SelectTrigger className="bg-white/5 border-white/10 text-white">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {MODELS.map((m) => (
                  <SelectItem key={m.value} value={m.value}>{m.label}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div className="space-y-1.5">
            <Label className="text-white/70 text-xs uppercase tracking-wider">Ratio</Label>
            <Select value={ratioKey} onValueChange={setRatioKey}>
              <SelectTrigger className="bg-white/5 border-white/10 text-white">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {RATIOS.map((r) => (
                  <SelectItem key={r.value} value={r.value}>{r.label}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </div>

        <div className="space-y-1.5">
          <Label className="text-white/70 text-xs uppercase tracking-wider">Seed</Label>
          <div className="flex gap-2">
            <input
              type="number"
              value={seed}
              onChange={(e) => setSeed(Number(e.target.value))}
              className="flex-1 bg-white/5 border border-white/10 rounded-md px-3 py-2 text-white text-sm"
            />
            <Button variant="secondary" size="icon" onClick={randomSeed} className="bg-white/5 border border-white/10 hover:bg-white/10">
              <Shuffle className="w-4 h-4" />
            </Button>
          </div>
        </div>

        <Button
          onClick={handleGenerate}
          disabled={!prompt.trim() || generating}
          className="w-full bg-gradient-to-r from-violet-500 to-fuchsia-500 hover:from-violet-400 hover:to-fuchsia-400 text-white border-0 h-11"
        >
          {generating ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : <Sparkles className="w-4 h-4 mr-2" />}
          {generating ? "Generating…" : "Generate Image"}
        </Button>
        <p className="text-[11px] text-white/30 text-center -mt-2">100% free · no credits used</p>
      </div>

      {/* Result + Gallery */}
      <div className="space-y-6">
        <div className="rounded-2xl bg-white/[0.02] border border-white/10 p-4 min-h-[320px] flex items-center justify-center">
          {!current ? (
            <div className="text-center text-white/30 py-20">
              <ImageIcon className="w-12 h-12 mx-auto mb-3 opacity-40" />
              <p className="text-sm">Your generated image will appear here</p>
            </div>
          ) : (
            <div className="w-full space-y-3">
              <div className="relative rounded-xl overflow-hidden bg-black/40 flex items-center justify-center" style={{ aspectRatio: `${ratio.w} / ${ratio.h}` }}>
                {generating && (
                  <div className="absolute inset-0 flex flex-col items-center justify-center gap-3 z-10">
                    <Loader2 className="w-8 h-8 text-violet-400 animate-spin" />
                    <p className="text-white/40 text-sm">Painting your image…</p>
                  </div>
                )}
                <img
                  key={current.url}
                  src={current.url}
                  alt={current.prompt}
                  onLoad={handleLoaded}
                  onError={() => setGenerating(false)}
                  crossOrigin="anonymous"
                  className={`w-full h-full object-contain transition-opacity duration-500 ${generating ? "opacity-0" : "opacity-100"}`}
                />
              </div>
              <div className="flex items-center justify-between gap-2">
                <p className="text-xs text-white/40 truncate flex-1">{current.prompt}</p>
                <div className="flex items-center gap-2">
                  <ShareButton mediaType="image" prompt={current.prompt} url={current.url} width={current.ratio.w} height={current.ratio.h} model={current.model} disabled={generating} />
                  <Button
                    variant="secondary"
                    size="sm"
                    onClick={handleDownload}
                    disabled={generating || downloading}
                    className="bg-white/5 border border-white/10 hover:bg-white/10 text-white"
                  >
                    {downloading ? <Loader2 className="w-4 h-4 mr-1.5 animate-spin" /> : <Download className="w-4 h-4 mr-1.5" />}
                    Download
                  </Button>
                </div>
              </div>
            </div>
          )}
        </div>

        {gallery.length > 0 && (
          <div>
            <p className="text-xs uppercase tracking-wider text-white/40 mb-3">Session Gallery</p>
            <div className="grid grid-cols-3 sm:grid-cols-4 md:grid-cols-5 gap-2">
              {gallery.map((g) => (
                <button
                  key={g.url}
                  onClick={() => { setCurrent(g); setGenerating(false); }}
                  className={`rounded-lg overflow-hidden border transition ${current?.url === g.url ? "border-violet-400" : "border-white/10 hover:border-white/30"}`}
                >
                  <img src={g.url} alt={g.prompt} className="w-full aspect-square object-cover" />
                </button>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}