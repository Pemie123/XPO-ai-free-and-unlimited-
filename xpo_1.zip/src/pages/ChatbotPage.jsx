import React, { useState, useRef, useEffect } from "react";
import { Link } from "react-router-dom";
import { MessageCircle, Send, Mic, Volume2, VolumeX, Loader2, ArrowLeft } from "lucide-react";
import { base44 } from "@/api/base44Client";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

const LANGUAGES = [
  { code: "en-US", label: "English", name: "English" },
  { code: "nl-NL", label: "Nederlands", name: "Dutch" },
  { code: "es-ES", label: "Español", name: "Spanish" },
  { code: "zh-CN", label: "中文", name: "Chinese" },
];

export default function ChatbotPage() {
  const [langCode, setLangCode] = useState("en-US");
  const [messages, setMessages] = useState([]);
  const [input, setInput] = useState("");
  const [thinking, setThinking] = useState(false);
  const [listening, setListening] = useState(false);
  const [voiceOn, setVoiceOn] = useState(true);
  const recognitionRef = useRef(null);
  const scrollRef = useRef(null);
  const speechPrimed = useRef(false);

  const lang = LANGUAGES.find((l) => l.code === langCode);

  useEffect(() => {
    scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight, behavior: "smooth" });
  }, [messages, thinking]);

  // Prime speech synthesis for mobile (iOS requires a user gesture before speak works)
  const primeSpeech = () => {
    if (speechPrimed.current) return;
    speechPrimed.current = true;
    if ("speechSynthesis" in window) {
      const u = new SpeechSynthesisUtterance("");
      u.volume = 0;
      u.lang = langCode;
      window.speechSynthesis.speak(u);
    }
  };

  const speak = (text) => {
    if (!voiceOn || !text || !("speechSynthesis" in window)) return;
    window.speechSynthesis.cancel();
    const u = new SpeechSynthesisUtterance(text);
    u.lang = langCode;
    u.rate = 1;
    window.speechSynthesis.speak(u);
  };

  const sendMessage = async (text) => {
    primeSpeech();
    const userText = (text || input).trim();
    if (!userText || thinking) return;
    setMessages((prev) => [...prev, { role: "user", text: userText }]);
    setInput("");
    setThinking(true);
    try {
      const res = await base44.integrations.Core.InvokeLLM({
        prompt: `You are a helpful, friendly AI assistant. Always respond in ${lang.name} (${lang.label}). Keep answers concise and conversational.\n\nUser: ${userText}`,
      });
      setMessages((prev) => [...prev, { role: "ai", text: res }]);
      speak(res);
    } catch (e) {
      setMessages((prev) => [...prev, { role: "ai", text: "⚠️ Connection error." }]);
    } finally {
      setThinking(false);
    }
  };

  const toggleListening = () => {
    primeSpeech();
    if (listening) {
      recognitionRef.current?.stop();
      setListening(false);
      return;
    }
    const SR = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (!SR) {
      alert("Voice input is not supported in this browser. Try Chrome or Safari.");
      return;
    }
    const recognition = new SR();
    recognition.lang = langCode;
    recognition.interimResults = false;
    recognition.continuous = false;
    recognition.maxAlternatives = 1;
    recognition.onresult = (e) => {
      const transcript = e.results[0][0].transcript;
      setInput(transcript);
      sendMessage(transcript);
    };
    recognition.onerror = (e) => {
      setListening(false);
      if (e.error === "not-allowed" || e.error === "service-not-allowed") {
        alert("Please allow microphone access in your browser settings.");
      }
    };
    recognition.onend = () => setListening(false);
    try {
      recognition.start();
      recognitionRef.current = recognition;
      setListening(true);
    } catch (e) {
      setListening(false);
    }
  };

  return (
    <div className="h-screen w-full bg-gradient-to-b from-[#0c0a14] to-[#080610] text-white flex flex-col">
      {/* Header */}
      <div className="flex items-center justify-between gap-2 p-3 border-b border-white/10 bg-white/5 shrink-0">
        <Link to="/" className="inline-flex items-center gap-2 text-sm text-white/60 hover:text-white transition shrink-0">
          <ArrowLeft className="w-4 h-4" /> Back
        </Link>
        <div className="flex items-center gap-2 min-w-0">
          <span className="text-xs text-white/50 hidden sm:inline">Language</span>
          <Select value={langCode} onValueChange={setLangCode}>
            <SelectTrigger className="h-8 w-[130px] bg-white/5 border-white/10 text-white text-xs">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {LANGUAGES.map((l) => (
                <SelectItem key={l.code} value={l.code}>{l.label}</SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
        <button
          onClick={() => {
            setVoiceOn(!voiceOn);
            if (voiceOn) window.speechSynthesis?.cancel();
          }}
          className={`p-2 rounded-lg transition shrink-0 ${voiceOn ? "text-fuchsia-300 hover:bg-white/10" : "text-white/30 hover:bg-white/5"}`}
          title={voiceOn ? "Voice on" : "Voice off"}
        >
          {voiceOn ? <Volume2 className="w-5 h-5" /> : <VolumeX className="w-5 h-5" />}
        </button>
      </div>

      {/* Messages */}
      <div ref={scrollRef} className="flex-1 overflow-y-auto p-4 space-y-3 no-scrollbar">
        {messages.length === 0 && (
          <div className="text-center text-white/30 py-20">
            <MessageCircle className="w-12 h-12 mx-auto mb-3 opacity-40" />
            <p className="text-base">Ask me anything in {lang.label}!</p>
            <p className="text-sm mt-1">Type or tap the mic to speak 🎤</p>
          </div>
        )}
        {messages.map((m, i) => (
          <div key={i} className={`flex ${m.role === "user" ? "justify-end" : "justify-start"}`}>
            <div className={`max-w-[80%] px-4 py-2.5 rounded-2xl text-sm sm:text-base ${m.role === "user" ? "bg-gradient-to-br from-violet-600 to-fuchsia-600 text-white rounded-br-sm" : "bg-white/10 text-white/90 rounded-bl-sm"}`}>
              {m.text}
            </div>
          </div>
        ))}
        {thinking && (
          <div className="flex justify-start">
            <div className="bg-white/10 px-4 py-2.5 rounded-2xl rounded-bl-sm">
              <Loader2 className="w-5 h-5 text-white/50 animate-spin" />
            </div>
          </div>
        )}
      </div>

      {/* Input bar */}
      <div className="flex items-center gap-2 p-3 border-t border-white/10 bg-white/5 shrink-0">
        <button
          onClick={toggleListening}
          className={`flex-shrink-0 w-11 h-11 flex items-center justify-center rounded-full transition touch-manipulation ${listening ? "bg-red-500 text-white animate-pulse" : "bg-white/10 text-fuchsia-300 hover:bg-white/20"}`}
          title="Voice input"
        >
          <Mic className="w-5 h-5" />
        </button>
        <input
          value={input}
          onChange={(e) => setInput(e.target.value)}
          onKeyDown={(e) => e.key === "Enter" && sendMessage()}
          placeholder={`Type in ${lang.label}…`}
          className="flex-1 bg-white/5 border border-white/10 rounded-full px-4 py-2.5 text-base text-white placeholder:text-white/30 focus:outline-none focus:ring-1 focus:ring-fuchsia-500/50"
        />
        <button
          onClick={() => sendMessage()}
          disabled={!input.trim() || thinking}
          className="flex-shrink-0 w-11 h-11 flex items-center justify-center rounded-full bg-gradient-to-r from-violet-600 to-fuchsia-600 text-white disabled:opacity-30 transition hover:scale-105 touch-manipulation"
        >
          <Send className="w-5 h-5" />
        </button>
      </div>
    </div>
  );
}