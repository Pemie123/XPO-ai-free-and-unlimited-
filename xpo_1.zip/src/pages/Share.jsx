import React, { useState, useEffect } from "react";
import { useParams, Link } from "react-router-dom";
import { base44 } from "@/api/base44Client";
import { ArrowLeft, Loader2, Compass } from "lucide-react";
import LikeButton from "@/components/LikeButton";

export default function Share() {
  const { id } = useParams();
  const [item, setItem] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(false);

  useEffect(() => {
    base44.entities.SharedMedia.get(id)
      .then(setItem)
      .catch(() => setError(true))
      .finally(() => setLoading(false));
  }, [id]);

  return (
    <div className="min-h-screen bg-gradient-to-b from-[#0c0a14] via-[#100a1c] to-[#080610] text-white">
      <div className="max-w-3xl mx-auto px-4 py-10">
        <div className="flex items-center justify-between mb-8">
          <Link to="/" className="inline-flex items-center gap-2 text-sm text-white/50 hover:text-white transition">
            <ArrowLeft className="w-4 h-4" /> Back to generator
          </Link>
          <Link to="/explore" className="inline-flex items-center gap-1.5 text-sm text-violet-300 hover:text-violet-200 transition">
            <Compass className="w-4 h-4" /> Explore
          </Link>
        </div>

        {loading && (
          <div className="flex justify-center py-32">
            <Loader2 className="w-8 h-8 text-violet-400 animate-spin" />
          </div>
        )}

        {error && (
          <div className="text-center py-32 text-white/40">
            <p className="text-sm">This shared media could not be found.</p>
          </div>
        )}

        {item && (
          <div className="space-y-4">
            <div className="rounded-2xl overflow-hidden border border-white/10 bg-black/40 flex items-center justify-center" style={{ aspectRatio: `${item.width || 1} / ${item.height || 1}` }}>
              {item.media_type === "video" ? (
                <video src={item.media_url} controls autoPlay loop className="w-full h-full object-contain" />
              ) : (
                <img src={item.media_url} alt={item.prompt} className="w-full h-full object-contain" />
              )}
            </div>
            <div className="flex items-center justify-between gap-3 px-1">
              <p className="text-sm text-white/50 flex-1">{item.prompt}</p>
              <LikeButton item={item} />
            </div>
          </div>
        )}
      </div>
    </div>
  );
}