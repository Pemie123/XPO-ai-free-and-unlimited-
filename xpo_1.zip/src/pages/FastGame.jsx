import React, { useState, useEffect, useRef } from "react";
import { Link } from "react-router-dom";
import { base44 } from "@/api/base44Client";
import { ArrowLeft, Loader2, Flame, Clock, Gamepad2, Globe } from "lucide-react";
import LikeButton from "@/components/LikeButton";
import SubscribeButton from "@/components/SubscribeButton";

const KEY_MAP = {
  z: [{ key: "ArrowUp", code: "ArrowUp", keyCode: 38 }, { key: "w", code: "KeyW", keyCode: 87 }],
  s: [{ key: "ArrowDown", code: "ArrowDown", keyCode: 40 }, { key: "s", code: "KeyS", keyCode: 83 }],
  q: [{ key: "ArrowLeft", code: "ArrowLeft", keyCode: 37 }, { key: "a", code: "KeyA", keyCode: 65 }],
  d: [{ key: "ArrowRight", code: "ArrowRight", keyCode: 39 }, { key: "d", code: "KeyD", keyCode: 68 }],
};

const INJECT_SCRIPT = `<script>(function(){window.addEventListener('message',function(e){if(e.data&&e.data.type==='fg-key'){var d=e.data;d.keys.forEach(function(k){var ev=new KeyboardEvent(d.eventType,{key:k.key,code:k.code,bubbles:true,cancelable:true});try{Object.defineProperty(ev,'keyCode',{get:function(){return k.keyCode;}});Object.defineProperty(ev,'which',{get:function(){return k.keyCode;}});}catch(e){}document.dispatchEvent(ev);var el=document.activeElement;if(el&&el!==document.body){el.dispatchEvent(ev);}});}if(e.data&&e.data.type==='fg-pause'){document.querySelectorAll('audio,video').forEach(function(el){el.pause();el.currentTime=0;});}});})();</script>`;

function injectKeyControls(html) {
  if (!html || html.includes("fg-key")) return html;
  if (html.includes("</body>")) return html.replace("</body>", INJECT_SCRIPT + "</body>");
  if (html.includes("</html>")) return html.replace("</html>", INJECT_SCRIPT + "</html>");
  return html + INJECT_SCRIPT;
}

export default function FastGame() {
  const [items, setItems] = useState([]);
  const [loading, setLoading] = useState(true);
  const [sort, setSort] = useState("latest");
  const [category, setCategory] = useState("all");

  const containerRef = useRef(null);
  const activeIndex = useRef(0);

  useEffect(() => {
    setLoading(true);
    base44.entities.SharedApp.list("-created_date", 60)
      .then((all) => {
        let filtered = category === "all" ? all : all.filter((i) => i.app_type === category);
        if (sort === "trending") {
          filtered = [...filtered].sort((a, b) => (b.likes || 0) - (a.likes || 0));
        }
        setItems(filtered);
      })
      .finally(() => setLoading(false));
  }, [sort, category]);

  useEffect(() => {
    if (!items.length) return;
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting && entry.intersectionRatio > 0.5) {
            activeIndex.current = Number(entry.target.dataset.index);
          } else if (!entry.isIntersecting) {
            const iframe = entry.target.querySelector("iframe");
            if (iframe && iframe.contentWindow) {
              iframe.contentWindow.postMessage({ type: "fg-pause" }, "*");
            }
          }
        });
      },
      { threshold: [0.5] }
    );
    const cards = containerRef.current?.querySelectorAll("[data-index]");
    cards?.forEach((card) => observer.observe(card));
    return () => observer.disconnect();
  }, [items]);

  useEffect(() => {
    const handleKey = (e) => {
      if (e.key === "ArrowDown" || e.key === "ArrowUp") {
        e.preventDefault();
        const container = containerRef.current;
        if (!container) return;
        const dir = e.key === "ArrowDown" ? 1 : -1;
        container.scrollBy({ top: dir * window.innerHeight, behavior: "smooth" });
        return;
      }
      const mapped = KEY_MAP[e.key.toLowerCase()];
      if (mapped) {
        e.preventDefault();
        const card = containerRef.current?.querySelector(`[data-index="${activeIndex.current}"]`);
        const iframe = card?.querySelector("iframe");
        if (iframe && iframe.contentWindow) {
          iframe.contentWindow.postMessage(
            { type: "fg-key", eventType: e.type, keys: mapped },
            "*"
          );
        }
      }
    };
    window.addEventListener("keydown", handleKey);
    window.addEventListener("keyup", handleKey);
    return () => {
      window.removeEventListener("keydown", handleKey);
      window.removeEventListener("keyup", handleKey);
    };
  }, []);

  return (
    <div className="h-screen w-full bg-black overflow-hidden relative">
      {/* Top bar */}
      <div className="absolute top-0 left-0 right-0 z-20 p-4 bg-gradient-to-b from-black/70 to-transparent pointer-events-none">
        <div className="flex items-center justify-between">
          <Link to="/" className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-white/10 backdrop-blur-sm border border-white/15 text-sm text-white font-medium hover:bg-white/20 transition pointer-events-auto">
            <ArrowLeft className="w-4 h-4" /> Back
          </Link>
          <span className="text-white font-bold tracking-[0.2em] text-sm">FASTGAME</span>
          <span className="w-12" />
        </div>
        {/* Sort + Filter */}
        <div className="flex items-center gap-2 mt-3 pointer-events-auto flex-wrap">
          <div className="inline-flex rounded-lg bg-black/50 border border-white/10 overflow-hidden">
            <button onClick={() => setSort("latest")} className={`flex items-center gap-1 px-3 py-1.5 text-xs transition ${sort === "latest" ? "bg-white/15 text-white" : "text-white/50"}`}>
              <Clock className="w-3 h-3" /> Latest
            </button>
            <button onClick={() => setSort("trending")} className={`flex items-center gap-1 px-3 py-1.5 text-xs transition ${sort === "trending" ? "bg-white/15 text-white" : "text-white/50"}`}>
              <Flame className="w-3 h-3" /> Trending
            </button>
          </div>
          <div className="inline-flex rounded-lg bg-black/50 border border-white/10 overflow-hidden">
            <button onClick={() => setCategory("all")} className={`px-3 py-1.5 text-xs transition ${category === "all" ? "bg-white/15 text-white" : "text-white/50"}`}>All</button>
            <button onClick={() => setCategory("game")} className={`flex items-center gap-1 px-3 py-1.5 text-xs transition ${category === "game" ? "bg-white/15 text-white" : "text-white/50"}`}>
              <Gamepad2 className="w-3 h-3" /> Games
            </button>
            <button onClick={() => setCategory("website")} className={`flex items-center gap-1 px-3 py-1.5 text-xs transition ${category === "website" ? "bg-white/15 text-white" : "text-white/50"}`}>
              <Globe className="w-3 h-3" /> Sites
            </button>
          </div>
        </div>
      </div>

      {/* Side hint */}
      <div className="absolute right-3 top-1/2 -translate-y-1/2 z-20 flex flex-col items-center gap-1 text-white/30 text-[10px] writing-vertical pointer-events-none">
        <span>SWIPE ↑</span>
      </div>
      <div className="hidden md:flex absolute left-3 bottom-28 z-20 flex-col gap-1 text-white/30 text-[10px] font-mono pointer-events-none">
        <span>Z ↑</span>
        <span>S ↓</span>
        <span>Q ←</span>
        <span>D →</span>
      </div>

      {loading ? (
        <div className="flex justify-center items-center h-full">
          <Loader2 className="w-8 h-8 text-fuchsia-400 animate-spin" />
        </div>
      ) : items.length === 0 ? (
        <div className="flex flex-col justify-center items-center h-full text-white/40 gap-3">
          <p className="text-sm">No shared games or websites yet.</p>
          <Link to="/" className="text-sm text-fuchsia-300 hover:text-fuchsia-200">Create & share something →</Link>
        </div>
      ) : (
        <div ref={containerRef} className="h-full overflow-y-scroll snap-y snap-mandatory no-scrollbar">
          {items.map((item, index) => (
            <div key={item.id} data-index={index} className="h-screen w-full snap-start relative bg-black overflow-hidden">
              <iframe
                srcDoc={injectKeyControls(item.content)}
                title={item.title}
                className="w-full h-full border-0"
                sandbox="allow-scripts"
                loading="lazy"
                tabIndex={-1}
              />
              {/* Actions */}
              <div className="absolute right-3 bottom-28 z-20 flex flex-col gap-3 items-center">
                <LikeButton item={item} entityName="SharedApp" />
              </div>
              {/* gradient + prompt */}
              <div className="absolute bottom-0 left-0 right-0 p-6 pb-10 bg-gradient-to-t from-black/85 via-black/30 to-transparent pointer-events-none">
                <span className="inline-block text-[10px] uppercase tracking-wider text-fuchsia-300/60 mb-1">
                  {item.app_type}
                </span>
                <Link to={`/a/${item.id}`} target="_blank" rel="noopener noreferrer" className="text-white text-sm max-w-lg block hover:text-fuchsia-300 transition pointer-events-auto">
                  {item.title || item.prompt}
                </Link>
                <p className="text-xs text-white/40 mt-1 max-w-md truncate">{item.prompt}</p>
                {item.username && (
                  <div className="flex items-center gap-2 mt-2 pointer-events-auto">
                    <span className="text-xs text-white/50">@{item.username}</span>
                    <SubscribeButton creatorUsername={item.username} />
                  </div>
                )}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}