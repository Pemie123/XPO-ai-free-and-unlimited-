import React, { useState, useEffect } from "react";
import { useParams, Link } from "react-router-dom";
import { base44 } from "@/api/base44Client";
import { ArrowLeft, Loader2 } from "lucide-react";
import LikeButton from "@/components/LikeButton";

export default function AppView() {
  const { id } = useParams();
  const [item, setItem] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    base44.entities.SharedApp.get(id)
      .then(setItem)
      .catch(() => setItem(null))
      .finally(() => setLoading(false));
  }, [id]);

  if (loading) {
    return (
      <div className="h-screen flex items-center justify-center bg-black">
        <Loader2 className="w-8 h-8 text-fuchsia-400 animate-spin" />
      </div>
    );
  }

  if (!item) {
    return (
      <div className="h-screen flex flex-col items-center justify-center bg-black text-white/40 gap-3">
        <p className="text-sm">This creation no longer exists.</p>
        <Link to="/fastgame" className="text-sm text-fuchsia-300 hover:text-fuchsia-200">Back to FASTGAME →</Link>
      </div>
    );
  }

  return (
    <div className="h-screen w-full bg-black flex flex-col">
      <div className="flex items-center justify-between p-3 border-b border-white/10 shrink-0">
        <Link to="/fastgame" className="inline-flex items-center gap-2 text-sm text-white/70 hover:text-white transition">
          <ArrowLeft className="w-4 h-4" /> FASTGAME
        </Link>
        <span className="text-xs text-white/40 uppercase tracking-wider">{item.app_type}</span>
        <div className="flex items-center gap-3">
          <LikeButton item={item} entityName="SharedApp" />
        </div>
      </div>
      <iframe
        srcDoc={item.content}
        title={item.title}
        className="flex-1 w-full border-0"
        sandbox="allow-scripts"
      />
    </div>
  );
}