import React, { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import { base44 } from "@/api/base44Client";
import { ArrowLeft, Loader2, ImageIcon, Film } from "lucide-react";
import LikeButton from "@/components/LikeButton";
import SubscribeButton from "@/components/SubscribeButton";

export default function Explore() {
  const [allItems, setAllItems] = useState([]);
  const [category, setCategory] = useState("all");
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    base44.entities.SharedMedia.list("-created_date", 60)
      .then(setAllItems)
      .finally(() => setLoading(false));
  }, []);

  const items = category === "all" ? allItems : allItems.filter((i) => i.media_type === category);

  return (
    <div className="h-screen w-full bg-black overflow-hidden relative">
      {/* Top bar */}
      <div className="absolute top-0 left-0 right-0 z-20 p-4 bg-gradient-to-b from-black/70 to-transparent pointer-events-none">
        <div className="flex items-center justify-between">
          <Link to="/" className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-white/10 backdrop-blur-sm border border-white/15 text-sm text-white font-medium hover:bg-white/20 transition pointer-events-auto">
            <ArrowLeft className="w-4 h-4" /> Back
          </Link>
          <span className="text-white font-bold tracking-[0.2em] text-sm">FASTSWIPE</span>
          <span className="w-12" />
        </div>
        <div className="flex items-center gap-2 mt-3 pointer-events-auto">
          <div className="inline-flex rounded-lg bg-black/50 border border-white/10 overflow-hidden">
            <button onClick={() => setCategory("all")} className={`px-3 py-1.5 text-xs transition ${category === "all" ? "bg-white/15 text-white" : "text-white/50"}`}>All</button>
            <button onClick={() => setCategory("image")} className={`flex items-center gap-1 px-3 py-1.5 text-xs transition ${category === "image" ? "bg-white/15 text-white" : "text-white/50"}`}>
              <ImageIcon className="w-3 h-3" /> Images
            </button>
            <button onClick={() => setCategory("video")} className={`flex items-center gap-1 px-3 py-1.5 text-xs transition ${category === "video" ? "bg-white/15 text-white" : "text-white/50"}`}>
              <Film className="w-3 h-3" /> Videos
            </button>
          </div>
        </div>
      </div>

      {/* Side hint */}
      <div className="absolute right-3 top-1/2 -translate-y-1/2 z-20 flex flex-col items-center gap-1 text-white/30 text-[10px] writing-vertical pointer-events-none">
        <span>SWIPE ↑</span>
      </div>

      {loading ? (
        <div className="flex justify-center items-center h-full">
          <Loader2 className="w-8 h-8 text-violet-400 animate-spin" />
        </div>
      ) : items.length === 0 ? (
        <div className="flex flex-col justify-center items-center h-full text-white/40 gap-3">
          <p className="text-sm">No shared creations yet.</p>
          <Link to="/" className="text-sm text-violet-300 hover:text-violet-200">Generate & share something →</Link>
        </div>
      ) : (
        <div className="h-full overflow-y-scroll snap-y snap-mandatory no-scrollbar">
          {items.map((item) => (
            <div key={item.id} className="h-screen w-full snap-start relative flex items-center justify-center bg-black overflow-hidden">
              {item.media_type === "video" ? (
                <video src={item.media_url} autoPlay muted loop playsInline className="w-full h-full object-cover" />
              ) : (
                <img src={item.media_url} alt={item.prompt} className="w-full h-full object-cover animate-kenburns" />
              )}
              {/* Like button */}
              <div className="absolute right-3 bottom-28 z-20">
                <LikeButton item={item} />
              </div>
              {/* gradient + prompt */}
              <div className="absolute bottom-0 left-0 right-0 p-6 pb-10 bg-gradient-to-t from-black/85 via-black/30 to-transparent pointer-events-none">
                <Link to={`/s/${item.id}`} className="text-white/90 text-sm max-w-lg block hover:text-violet-300 transition pointer-events-auto">
                  {item.prompt}
                </Link>
                <span className="inline-block mt-2 text-[10px] uppercase tracking-wider text-white/40">
                  {item.media_type}
                </span>
                {item.username && (
                  <div className="flex items-center gap-2 mt-2 pointer-events-auto">
                    <span className="text-xs text-white/50">@{item.username}</span>
                    <SubscribeButton creatorUsername={item.username} />
                  </div>
                )}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}