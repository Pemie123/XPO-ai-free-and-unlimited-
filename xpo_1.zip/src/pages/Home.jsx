import React, { useState, useEffect } from "react";
import { ImageIcon, Film, Compass, Gamepad2, User } from "lucide-react";
import { Link } from "react-router-dom";
import ImageGenerator from "@/components/ImageGenerator";
import VideoGenerator from "@/components/VideoGenerator";
import Chatbot from "@/components/Chatbot";
import UsernamePrompt from "@/components/UsernamePrompt";

export default function Home() {
  const [tab, setTab] = useState("image");
  const [remixPrompt, setRemixPrompt] = useState(null);

  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const remixPromptParam = params.get("remix_prompt");
    const tabParam = params.get("tab");
    if (tabParam === "image" || tabParam === "video") setTab(tabParam);
    if (remixPromptParam) {
      setRemixPrompt(decodeURIComponent(remixPromptParam));
    }
  }, []);

  return (
    <div className="min-h-screen bg-gradient-to-b from-[#0c0a14] via-[#100a1c] to-[#080610] text-white">
      {/* Ambient glow */}
      <div className="pointer-events-none fixed inset-0 overflow-hidden">
        <div className="absolute -top-40 -left-40 w-96 h-96 rounded-full bg-violet-600/20 blur-[120px]" />
        <div className="absolute top-1/3 -right-40 w-96 h-96 rounded-full bg-fuchsia-600/15 blur-[120px]" />
      </div>

      <div className="relative max-w-5xl mx-auto px-4 py-10 sm:py-14">
        {/* Header */}
        <div className="text-center mb-10">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-white/5 border border-white/10 text-xs text-white/60 mb-5">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
            Free forever · no credits
          </div>
          <h1 className="text-4xl sm:text-5xl font-bold tracking-tight bg-gradient-to-b from-white to-white/60 bg-clip-text text-transparent">
            XPO-AI
          </h1>
          <p className="text-white/40 mt-3 text-sm sm:text-base max-w-md mx-auto">
            Generate stunning AI images and videos for free — powered by Pollinations, not your wallet.
          </p>
          <div className="flex items-center justify-center gap-4 mt-4 flex-wrap">
            <Link to="/profile" className="inline-flex items-center gap-1.5 text-sm text-white/70 hover:text-white transition">
              <User className="w-4 h-4" /> PROFILE
            </Link>
            <span className="text-white/20">·</span>
            <Link to="/fastgame" className="inline-flex items-center gap-1.5 text-sm text-fuchsia-300 hover:text-fuchsia-200 transition">
              <Gamepad2 className="w-4 h-4" /> Open FASTGAME
            </Link>
            <span className="text-white/20">·</span>
            <Link to="/explore" className="inline-flex items-center gap-1.5 text-sm text-violet-300 hover:text-violet-200 transition">
              <Compass className="w-4 h-4" /> Open FASTSWIPE
            </Link>
          </div>
        </div>

        {/* Tabs */}
        <div className="flex justify-center mb-8">
          <div className="inline-flex p-1 rounded-xl bg-white/5 border border-white/10 gap-1">
            <button
              onClick={() => setTab("image")}
              className={`flex items-center gap-2 px-5 py-2.5 rounded-lg text-sm font-medium transition ${tab === "image" ? "bg-white/10 text-white" : "text-white/40 hover:text-white/70"}`}
            >
              <ImageIcon className="w-4 h-4" /> Images
            </button>
            <button
              onClick={() => setTab("video")}
              className={`flex items-center gap-2 px-5 py-2.5 rounded-lg text-sm font-medium transition ${tab === "video" ? "bg-white/10 text-white" : "text-white/40 hover:text-white/70"}`}
            >
              <Film className="w-4 h-4" /> Videos
            </button>
          </div>
        </div>

        {/* Content */}
        {tab === "image" ? <ImageGenerator key={remixPrompt || "img"} initialPrompt={remixPrompt} /> : <VideoGenerator key={remixPrompt || "vid"} initialPrompt={remixPrompt} />}

        <footer className="text-center mt-12 text-xs text-white/20">
          Built with the free Pollinations API · no Base44 credits consumed
        </footer>
      </div>
      <Chatbot />
      <UsernamePrompt />
    </div>
  );
}