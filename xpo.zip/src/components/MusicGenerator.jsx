import React, { useState, useRef } from "react";
import { Music, Loader2, Play, Download, Sparkles, Square } from "lucide-react";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

const DURATIONS = [
  { value: 10, label: "10 seconds" },
  { value: 30, label: "30 seconds" },
  { value: 60, label: "1 minute" },
  { value: 120, label: "2 minutes" },
  { value: 180, label: "3 minutes" },
];

const SUGGESTIONS = [
  "A dreamy lo-fi hip-hop beat for studying",
  "An epic orchestral battle theme",
  "A cheerful 8-bit chiptune adventure",
  "A relaxing ambient piano melody",
];

export default function MusicGenerator({ initialPrompt }) {
  const [prompt, setPrompt] = useState(initialPrompt || "");
  const [duration, setDuration] = useState(30);
  const [generating, setGenerating] = useState(false);
  const [composition, setComposition] = useState(null);
  const [playing, setPlaying] = useState(false);
  const [audioUrl, setAudioUrl] = useState(null);
  const [progress, setProgress] = useState(0);
  const audioCtxRef = useRef(null);
  const recorderRef = useRef(null);
  const chunksRef = useRef([]);
  const stopTimeoutRef = useRef(null);
  const progressIntervalRef = useRef(null);

  const handleGenerate = async () => {
    if (!prompt.trim() || generating) return;
    setGenerating(true);
    setComposition(null);
    setAudioUrl(null);
    setProgress(0);
    try {
      const res = await base44.integrations.Core.InvokeLLM({
        prompt: `You are a music composer AI. Create a musical composition based on: "${prompt.trim()}".

Generate a JSON object representing a musical piece of approximately ${duration} seconds.

Rules:
- "tempo": BPM (60-180)
- "tracks": array of 2-4 tracks
- Each track: "instrument" (one of "sine","sawtooth","square","triangle"), "volume" (0.1 to 0.4), "notes" array
- Each note: "freq" (frequency in Hz, use 0 for rest), "start" (seconds from 0), "dur" (duration in seconds)
- Use real musical frequencies (C4=261.63, D4=293.66, E4=329.63, F4=349.23, G4=392.00, A4=440.00, B4=493.88, C5=523.25)
- Create a melody, harmony, and bass line
- Fill the entire ${duration} seconds with notes
- Make it pleasant and matching the mood
- Keep total notes reasonable (10-40 per track)`,
        response_json_schema: {
          type: "object",
          properties: {
            tempo: { type: "number" },
            tracks: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  instrument: { type: "string" },
                  volume: { type: "number" },
                  notes: {
                    type: "array",
                    items: {
                      type: "object",
                      properties: {
                        freq: { type: "number" },
                        start: { type: "number" },
                        dur: { type: "number" },
                      },
                      required: ["freq", "start", "dur"],
                    },
                  },
                },
                required: ["instrument", "volume", "notes"],
              },
            },
          },
          required: ["tempo", "tracks"],
        },
      });
      setComposition(res);
    } catch (e) {
      console.error(e);
    } finally {
      setGenerating(false);
    }
  };

  const playAndRecord = () => {
    if (!composition || playing) return;
    setPlaying(true);
    setProgress(0);
    setAudioUrl(null);

    const ctx = new (window.AudioContext || window.webkitAudioContext)();
    audioCtxRef.current = ctx;

    const dest = ctx.createMediaStreamDestination();
    let recorder;
    try {
      recorder = new MediaRecorder(dest.stream, { mimeType: "audio/webm" });
    } catch {
      recorder = new MediaRecorder(dest.stream);
    }
    chunksRef.current = [];
    recorder.ondataavailable = (e) => {
      if (e.data.size > 0) chunksRef.current.push(e.data);
    };
    recorder.onstop = () => {
      const blob = new Blob(chunksRef.current, { type: "audio/webm" });
      setAudioUrl(URL.createObjectURL(blob));
      setPlaying(false);
    };
    recorderRef.current = recorder;

    const masterGain = ctx.createGain();
    masterGain.gain.value = 0.6;
    masterGain.connect(ctx.destination);
    masterGain.connect(dest);

    let totalDuration = 0;

    composition.tracks.forEach((track) => {
      const vol = Math.min(track.volume || 0.3, 0.4);
      track.notes.forEach((note) => {
        totalDuration = Math.max(totalDuration, note.start + note.dur);
        if (note.freq === 0) return;

        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        const waveType = ["sine", "sawtooth", "square", "triangle"].includes(track.instrument)
          ? track.instrument
          : "sine";
        osc.type = waveType;
        osc.frequency.value = note.freq;

        const startTime = ctx.currentTime + note.start;
        const endTime = startTime + note.dur;
        const attack = 0.02;
        const release = Math.min(0.08, note.dur * 0.3);

        gain.gain.setValueAtTime(0, startTime);
        gain.gain.linearRampToValueAtTime(vol, startTime + attack);
        gain.gain.setValueAtTime(vol, Math.max(startTime + attack, endTime - release));
        gain.gain.linearRampToValueAtTime(0, endTime);

        osc.connect(gain);
        gain.connect(masterGain);
        osc.start(startTime);
        osc.stop(endTime + 0.05);
      });
    });

    recorder.start();

    progressIntervalRef.current = setInterval(() => {
      const elapsed = ctx.currentTime;
      setProgress(Math.min(Math.round((elapsed / totalDuration) * 100), 100));
      if (elapsed >= totalDuration) {
        clearInterval(progressIntervalRef.current);
      }
    }, 100);

    stopTimeoutRef.current = setTimeout(() => {
      if (recorderRef.current && recorderRef.current.state !== "inactive") {
        recorderRef.current.stop();
      }
      clearInterval(progressIntervalRef.current);
      setProgress(100);
      ctx.close();
    }, (totalDuration + 1) * 1000);
  };

  const handleStop = () => {
    if (stopTimeoutRef.current) clearTimeout(stopTimeoutRef.current);
    if (progressIntervalRef.current) clearInterval(progressIntervalRef.current);
    if (recorderRef.current && recorderRef.current.state !== "inactive") {
      recorderRef.current.stop();
    }
    audioCtxRef.current?.close();
    setPlaying(false);
  };

  const handleDownload = () => {
    if (!audioUrl) return;
    const a = document.createElement("a");
    a.href = audioUrl;
    a.download = `xpo-music-${Date.now()}.webm`;
    a.click();
  };

  return (
    <div className="grid lg:grid-cols-[380px_1fr] gap-6">
      {/* Controls */}
      <div className="space-y-5 rounded-2xl bg-white/[0.04] border border-white/10 p-5 backdrop-blur-sm">
        <div className="space-y-2">
          <Label className="text-white/70 text-xs uppercase tracking-wider">Prompt</Label>
          <Textarea
            value={prompt}
            onChange={(e) => setPrompt(e.target.value)}
            placeholder="Describe the song you want… e.g. a dreamy lo-fi beat for studying"
            className="bg-white/5 border-white/10 text-white placeholder:text-white/30 resize-none min-h-[110px]"
          />
        </div>

        {!composition && (
          <div className="flex flex-wrap gap-1.5">
            {SUGGESTIONS.map((s) => (
              <button
                key={s}
                onClick={() => setPrompt(s)}
                className="text-[11px] px-2.5 py-1 rounded-full bg-white/5 hover:bg-white/10 text-white/50 hover:text-white/80 transition border border-white/5"
              >
                {s.split(" ").slice(0, 3).join(" ")}…
              </button>
            ))}
          </div>
        )}

        <div className="space-y-1.5">
          <Label className="text-white/70 text-xs uppercase tracking-wider">Duration</Label>
          <Select value={String(duration)} onValueChange={(v) => setDuration(Number(v))}>
            <SelectTrigger className="bg-white/5 border-white/10 text-white"><SelectValue /></SelectTrigger>
            <SelectContent>
              {DURATIONS.map((d) => <SelectItem key={d.value} value={String(d.value)}>{d.label}</SelectItem>)}
            </SelectContent>
          </Select>
        </div>

        <Button
          onClick={handleGenerate}
          disabled={!prompt.trim() || generating}
          className="w-full bg-gradient-to-r from-violet-500 to-fuchsia-500 hover:from-violet-400 hover:to-fuchsia-400 text-white border-0 h-11"
        >
          {generating ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : <Sparkles className="w-4 h-4 mr-2" />}
          {generating ? "Composing…" : "Generate Song"}
        </Button>
        <p className="text-[11px] text-white/30 text-center -mt-2">AI-composed · synthesized in your browser</p>
      </div>

      {/* Preview */}
      <div className="rounded-2xl bg-white/[0.02] border border-white/10 p-4 min-h-[320px] flex items-center justify-center">
        {!composition && !generating ? (
          <div className="text-center text-white/30 py-20">
            <Music className="w-12 h-12 mx-auto mb-3 opacity-40" />
            <p className="text-sm">Your generated song will appear here</p>
            <p className="text-xs text-white/20 mt-1">Describe a vibe, pick a length, and let AI compose it</p>
          </div>
        ) : generating ? (
          <div className="text-center text-white/50 py-20">
            <Loader2 className="w-10 h-10 mx-auto mb-4 text-fuchsia-400 animate-spin" />
            <p className="text-sm">Composing your song…</p>
          </div>
        ) : composition ? (
          <div className="w-full space-y-4 max-w-md mx-auto">
            <div className="text-center">
              <div className="w-20 h-20 rounded-full bg-gradient-to-br from-violet-600 to-fuchsia-600 flex items-center justify-center mx-auto mb-3">
                <Music className="w-10 h-10 text-white" />
              </div>
              <p className="text-white text-sm font-medium">{prompt}</p>
              <p className="text-xs text-white/40 mt-1">{composition.tempo} BPM · {composition.tracks.length} tracks</p>
            </div>

            {!playing && !audioUrl && (
              <Button
                onClick={playAndRecord}
                className="w-full bg-gradient-to-r from-violet-500 to-fuchsia-500 hover:from-violet-400 hover:to-fuchsia-400 text-white border-0 h-11"
              >
                <Play className="w-4 h-4 mr-2" /> Play & Record
              </Button>
            )}

            {playing && (
              <div className="space-y-2">
                <div className="flex items-center gap-3">
                  <div className="flex-1 h-2 bg-white/10 rounded-full overflow-hidden">
                    <div className="h-full bg-gradient-to-r from-violet-500 to-fuchsia-500 transition-all" style={{ width: `${progress}%` }} />
                  </div>
                  <Button variant="secondary" size="sm" onClick={handleStop} className="bg-white/5 border border-white/10 text-white">
                    <Square className="w-3.5 h-3.5 mr-1" /> Stop
                  </Button>
                </div>
                <p className="text-xs text-white/40 text-center">Playing & recording… {progress}%</p>
              </div>
            )}

            {audioUrl && (
              <div className="space-y-3">
                <audio src={audioUrl} controls className="w-full" />
                <div className="flex items-center justify-between gap-2">
                  <Button
                    variant="secondary"
                    size="sm"
                    onClick={playAndRecord}
                    className="bg-white/5 border border-white/10 text-white"
                  >
                    <Play className="w-4 h-4 mr-1.5" /> Replay
                  </Button>
                  <Button
                    size="sm"
                    onClick={handleDownload}
                    className="bg-gradient-to-r from-violet-500 to-fuchsia-500 hover:from-violet-400 hover:to-fuchsia-400 text-white border-0"
                  >
                    <Download className="w-4 h-4 mr-1.5" /> Download
                  </Button>
                </div>
              </div>
            )}
          </div>
        ) : null}
      </div>
    </div>
  );
}