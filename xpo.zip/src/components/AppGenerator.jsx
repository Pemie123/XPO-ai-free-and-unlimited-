import React, { useState } from "react";
import { Loader2, Sparkles, Gamepad2, Globe, RotateCcw, Music } from "lucide-react";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import AppShareButton from "@/components/AppShareButton";

const PROMPTS = {
  game: {
    icon: Gamepad2,
    system: `You are an expert HTML5 game developer. Create a complete, self-contained HTML5 game based on the user's request.

CRITICAL REQUIREMENTS:
- Return a SINGLE complete HTML document with ALL CSS and JavaScript inline — no external files, no CDN links
- The game must be fully playable, interactive, and fun
- Use HTML5 Canvas for graphics-heavy games, or DOM elements for simpler games
- Include score tracking, win/lose conditions, and a restart button where applicable
- Make it visually polished with modern CSS, gradients, and smooth animations
- The game must work when loaded directly in an iframe via srcDoc
- Fit within a typical browser viewport
- Add touch and keyboard controls as appropriate

Return a JSON object with:
- "html": the complete HTML document (including <!DOCTYPE html>, <html>, <head>, <body>)
- "title": a short catchy title (max 50 characters)`,
    placeholder: "Describe the game you want to build… e.g. a space shooter where you blast asteroids",
    label: "Game",
    suggestions: [
      "A snake game with neon glowing graphics",
      "A brick breaker with power-ups",
      "A flappy bird clone with a rocket ship",
      "A memory card matching game with emojis",
    ],
  },
  website: {
    icon: Globe,
    system: `You are an expert web developer. Create a complete, self-contained website based on the user's request.

CRITICAL REQUIREMENTS:
- Return a SINGLE complete HTML document with ALL CSS and JavaScript inline — no external files, no CDN links
- The website must be fully functional and visually impressive
- Use modern CSS with flexbox/grid, system fonts, smooth transitions, and responsive design
- Include realistic placeholder content that matches the website's purpose
- The site must work when loaded directly in an iframe via srcDoc
- Make the layout clean, modern, and professional
- Add interactive elements (buttons, hover effects, animations) where appropriate

Return a JSON object with:
- "html": the complete HTML document (including <!DOCTYPE html>, <html>, <head>, <body>)
- "title": a short title for the website (max 50 characters)`,
    placeholder: "Describe the website you want to build… e.g. a landing page for a coffee shop",
    label: "Website",
    suggestions: [
      "A landing page for a premium coffee brand",
      "A personal portfolio with dark theme",
      "A pricing page for a SaaS product",
      "A recipe blog homepage with cards",
    ],
  },
};

function injectMusic(html, musicUrl) {
  if (!musicUrl || !html) return html;
  const tag = `<audio src="${musicUrl}" autoplay loop style="display:none"></audio>`;
  if (html.includes("</body>")) return html.replace("</body>", tag + "</body>");
  if (html.includes("</html>")) return html.replace("</html>", tag + "</html>");
  return html + tag;
}

function cleanHtml(html) {
  let h = (html || "").trim();
  if (h.startsWith("```")) {
    h = h.replace(/^```(?:html)?\n?/, "").replace(/\n?```$/, "").trim();
  }
  return h;
}

export default function AppGenerator({ mode, initialPrompt, initialCode, initialTitle }) {
  const config = PROMPTS[mode];
  const Icon = config.icon;
  const [prompt, setPrompt] = useState(initialPrompt || "");
  const [code, setCode] = useState(initialCode || "");
  const [title, setTitle] = useState(initialTitle || "");
  const [generating, setGenerating] = useState(false);
  const [history, setHistory] = useState(initialPrompt ? [initialPrompt] : []);
  const [musicUrl, setMusicUrl] = useState("");
  const [uploadingMusic, setUploadingMusic] = useState(false);

  const handleMusicUpload = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setUploadingMusic(true);
    try {
      const res = await base44.integrations.Core.UploadFile({ file });
      setMusicUrl(res.file_url);
    } catch (err) {
      console.error(err);
    } finally {
      setUploadingMusic(false);
    }
  };

  const handleGenerate = async () => {
    if (!prompt.trim() || generating) return;
    setGenerating(true);
    try {
      const userPrompt = code
        ? `Here is the current code:\n\n${code}\n\nThe user wants this change: "${prompt.trim()}"\n\nApply ONLY the requested change while keeping everything else working. Return the complete modified HTML document.\n\n${config.system}`
        : `${config.system}\n\nUser request: "${prompt.trim()}"`;

      const res = await base44.integrations.Core.InvokeLLM({
        prompt: userPrompt,
        response_json_schema: {
          type: "object",
          properties: {
            html: { type: "string" },
            title: { type: "string" },
          },
          required: ["html", "title"],
        },
      });
      setCode(cleanHtml(res.html));
      setTitle(res.title || prompt.trim());
      setHistory((prev) => [...prev, prompt.trim()]);
      setPrompt("");
    } finally {
      setGenerating(false);
    }
  };

  const handleReset = () => {
    setCode("");
    setTitle("");
    setHistory([]);
    setPrompt("");
  };

  return (
    <div className="grid lg:grid-cols-[380px_1fr] gap-6">
      {/* Controls */}
      <div className="space-y-5 rounded-2xl bg-white/[0.04] border border-white/10 p-5 backdrop-blur-sm">
        <div className="space-y-2">
          <div className="flex items-center gap-2">
            <Label className="text-white/70 text-xs uppercase tracking-wider">{config.label} Prompt</Label>
            {initialCode && (
              <span className="text-[10px] uppercase tracking-wider text-fuchsia-300 bg-fuchsia-500/15 px-2 py-0.5 rounded-full">Remix</span>
            )}
          </div>
          <Textarea
            value={prompt}
            onChange={(e) => setPrompt(e.target.value)}
            placeholder={config.placeholder}
            className="bg-white/5 border-white/10 text-white placeholder:text-white/30 resize-none min-h-[110px]"
          />
        </div>

        {!code && (
          <div className="flex flex-wrap gap-1.5">
            {config.suggestions.map((s) => (
              <button
                key={s}
                onClick={() => setPrompt(s)}
                className="text-[11px] px-2.5 py-1 rounded-full bg-white/5 hover:bg-white/10 text-white/50 hover:text-white/80 transition border border-white/5"
              >
                {s.split(" ").slice(0, 3).join(" ")}…
              </button>
            ))}
          </div>
        )}

        {mode === "game" && (
          <div className="space-y-1.5">
            <Label className="text-white/70 text-xs uppercase tracking-wider flex items-center gap-1.5">
              <Music className="w-3 h-3" /> Background Music
            </Label>
            <input
              type="file"
              accept="audio/*"
              onChange={handleMusicUpload}
              disabled={uploadingMusic}
              className="text-xs text-white/40 file:mr-2 file:py-1 file:px-3 file:rounded-full file:border-0 file:bg-white/10 file:text-white/70 file:cursor-pointer w-full"
            />
            {uploadingMusic && <p className="text-[11px] text-white/40">Uploading…</p>}
            {musicUrl && !uploadingMusic && <p className="text-[11px] text-emerald-400">✓ Music added — will play in your game</p>}
          </div>
        )}

        {history.length > 0 && (
          <div className="space-y-1">
            <p className="text-[11px] text-white/30 uppercase tracking-wider">Changes ({history.length})</p>
            {history.map((h, i) => (
              <p key={i} className="text-xs text-white/40 truncate">→ {h}</p>
            ))}
          </div>
        )}

        <Button
          onClick={handleGenerate}
          disabled={!prompt.trim() || generating}
          className="w-full bg-gradient-to-r from-violet-500 to-fuchsia-500 hover:from-violet-400 hover:to-fuchsia-400 text-white border-0 h-11"
        >
          {generating ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : <Sparkles className="w-4 h-4 mr-2" />}
          {generating ? "Building…" : code ? "Apply Change" : `Create ${config.label}`}
        </Button>

        {code && (
          <Button variant="ghost" size="sm" onClick={handleReset} className="w-full text-white/40 hover:text-white/70">
            <RotateCcw className="w-3.5 h-3.5 mr-1.5" /> Start Over
          </Button>
        )}
        <p className="text-[11px] text-white/30 text-center -mt-2">Powered by AI · free to use</p>
      </div>

      {/* Preview */}
      <div className="space-y-3">
        <div className="rounded-2xl bg-white/[0.02] border border-white/10 p-4 min-h-[400px]">
          {!code ? (
            <div className="text-center text-white/30 py-20">
              <Icon className="w-12 h-12 mx-auto mb-3 opacity-40" />
              <p className="text-sm">{mode === "game" ? "Describe a game and it'll be built instantly" : "Describe a website and it'll be built instantly"}</p>
              <p className="text-xs text-white/20 mt-1">Then refine it with follow-up prompts</p>
            </div>
          ) : (
            <div className="space-y-3">
              <div className="rounded-xl overflow-hidden bg-white border border-white/10">
                <iframe
                  srcDoc={injectMusic(code, musicUrl)}
                  title={title}
                  className="w-full h-[500px] border-0"
                  sandbox="allow-scripts"
                />
              </div>
              <div className="flex items-center justify-between gap-2">
                <p className="text-xs text-white/40 truncate flex-1">{title}</p>
                <AppShareButton
                  appType={mode}
                  prompt={history.join(" → ")}
                  title={title}
                  code={code}
                  disabled={generating}
                />
              </div>
            </div>
          )}
        </div>

        {code && (
          <p className="text-xs text-white/30 text-center">
            Type a follow-up prompt above and hit "Apply Change" to modify your {config.label.toLowerCase()}
          </p>
        )}
      </div>
    </div>
  );
}