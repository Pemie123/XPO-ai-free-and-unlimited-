import React, { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import { base44 } from "@/api/base44Client";
import { ArrowLeft, Loader2, Trash2, GitFork, Heart, Upload, Users } from "lucide-react";
import UsernamePrompt from "@/components/UsernamePrompt";

const LIKED_KEY = "freeform_liked";

function getLikedIds() {
  try { return JSON.parse(localStorage.getItem(LIKED_KEY) || "[]"); } catch { return []; }
}

export default function Profile() {
  const [user, setUser] = useState(null);
  const [checking, setChecking] = useState(true);
  const [tab, setTab] = useState("uploads");
  const [items, setItems] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    base44.auth.me()
      .then((u) => {
        if (!u) { base44.auth.redirectToLogin("/profile"); return; }
        setUser(u);
      })
      .catch(() => base44.auth.redirectToLogin("/profile"))
      .finally(() => setChecking(false));
  }, []);

  useEffect(() => {
    if (!user) return;
    loadItems();
  }, [user, tab]);

  const loadItems = async () => {
    setLoading(true);
    try {
      if (tab === "uploads") {
        const [apps, media] = await Promise.all([
          base44.entities.SharedApp.filter({ created_by_id: user.id }, "-created_date", 100),
          base44.entities.SharedMedia.filter({ created_by_id: user.id }, "-created_date", 100),
        ]);
        setItems(
          [
            ...apps.map((a) => ({ ...a, _type: "app" })),
            ...media.map((m) => ({ ...m, _type: "media" })),
          ].sort((a, b) => new Date(b.created_date) - new Date(a.created_date))
        );
      } else if (tab === "liked") {
        const likedIds = getLikedIds();
        if (likedIds.length === 0) { setItems([]); return; }
        const [apps, media] = await Promise.all([
          base44.entities.SharedApp.list("-created_date", 100),
          base44.entities.SharedMedia.list("-created_date", 100),
        ]);
        setItems([
          ...apps.filter((a) => likedIds.includes(a.id)).map((a) => ({ ...a, _type: "app" })),
          ...media.filter((m) => likedIds.includes(m.id)).map((m) => ({ ...m, _type: "media" })),
        ]);
      } else if (tab === "subscriptions") {
        const subs = await base44.entities.Subscription.filter({ created_by_id: user.id }, "-created_date", 100);
        const usernames = subs.map((s) => s.creator_username);
        if (usernames.length === 0) { setItems([]); return; }
        const [apps, media] = await Promise.all([
          base44.entities.SharedApp.list("-created_date", 100),
          base44.entities.SharedMedia.list("-created_date", 100),
        ]);
        setItems(
          [
            ...apps.filter((a) => usernames.includes(a.username)).map((a) => ({ ...a, _type: "app" })),
            ...media.filter((m) => usernames.includes(m.username)).map((m) => ({ ...m, _type: "media" })),
          ].sort((a, b) => new Date(b.created_date) - new Date(a.created_date))
        );
      }
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  const handleDelete = async (item) => {
    const entityName = item._type === "app" ? "SharedApp" : "SharedMedia";
    try {
      await base44.entities[entityName].delete(item.id);
      setItems((prev) => prev.filter((i) => i.id !== item.id));
    } catch (e) {
      console.error(e);
    }
  };

  const handleRemix = (item) => {
    if (item._type === "app") {
      window.location.href = `/?tab=game&remix=${item.id}`;
    } else {
      const tabName = item.media_type === "video" ? "video" : "image";
      window.location.href = `/?tab=${tabName}&remix_prompt=${encodeURIComponent(item.prompt)}`;
    }
  };

  if (checking || !user) {
    return (
      <div className="h-screen flex items-center justify-center bg-black">
        <Loader2 className="w-8 h-8 text-fuchsia-400 animate-spin" />
      </div>
    );
  }

  const tabs = [
    { key: "uploads", label: "My Uploads", icon: Upload },
    { key: "liked", label: "Liked", icon: Heart },
    { key: "subscriptions", label: "Subscriptions", icon: Users },
  ];

  return (
    <div className="min-h-screen bg-gradient-to-b from-[#0c0a14] to-[#080610] text-white">
      <div className="max-w-4xl mx-auto px-4 py-8">
        {/* Header */}
        <div className="flex items-center justify-between mb-6">
          <Link to="/" className="inline-flex items-center gap-2 text-sm text-white/60 hover:text-white">
            <ArrowLeft className="w-4 h-4" /> Back
          </Link>
          <div className="text-center">
            <h1 className="text-xl font-bold">{user.username || "Profile"}</h1>
            <p className="text-xs text-white/40">{user.email}</p>
          </div>
          <span className="w-16" />
        </div>

        {/* Tabs */}
        <div className="flex justify-center gap-2 mb-6">
          {tabs.map((t) => (
            <button
              key={t.key}
              onClick={() => setTab(t.key)}
              className={`flex items-center gap-1.5 px-4 py-2 rounded-lg text-sm font-medium transition ${
                tab === t.key ? "bg-white/10 text-white" : "text-white/40 hover:text-white/70"
              }`}
            >
              <t.icon className="w-4 h-4" /> {t.label}
            </button>
          ))}
        </div>

        {/* Content grid */}
        {loading ? (
          <div className="flex justify-center py-20">
            <Loader2 className="w-8 h-8 text-fuchsia-400 animate-spin" />
          </div>
        ) : items.length === 0 ? (
          <div className="text-center text-white/30 py-20">
            <p className="text-sm">
              {tab === "uploads"
                ? "You haven't shared anything yet."
                : tab === "liked"
                ? "No liked content yet."
                : "Not subscribed to anyone yet."}
            </p>
            <Link to="/" className="inline-block mt-3 text-sm text-fuchsia-300 hover:text-fuchsia-200">
              Create something →
            </Link>
          </div>
        ) : (
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-3">
            {items.map((item) => (
              <div
                key={item.id}
                className="rounded-xl overflow-hidden bg-white/[0.03] border border-white/10 group relative"
              >
                <div className="h-32 bg-black/40 overflow-hidden">
                  {item._type === "app" ? (
                    <iframe
                      srcDoc={item.content}
                      title={item.title}
                      className="w-full h-full border-0 pointer-events-none"
                      sandbox="allow-scripts"
                    />
                  ) : item.media_type === "video" ? (
                    <video src={item.media_url} muted loop className="w-full h-full object-cover" />
                  ) : (
                    <img src={item.media_url} alt={item.prompt} className="w-full h-full object-cover" />
                  )}
                </div>
                <div className="p-2">
                  <p className="text-xs text-white/80 truncate">
                    {item._type === "app" ? item.title || item.prompt : item.prompt}
                  </p>
                  <span className="text-[10px] text-white/30 uppercase">
                    {item._type === "app" ? item.app_type : item.media_type}
                  </span>
                </div>
                {tab === "uploads" && (
                  <div className="absolute top-1 right-1 flex gap-1 opacity-0 group-hover:opacity-100 transition">
                    <button
                      onClick={() => handleRemix(item)}
                      className="w-7 h-7 rounded-full bg-black/60 flex items-center justify-center text-fuchsia-300 hover:bg-fuchsia-500/20"
                      title="Remix"
                    >
                      <GitFork className="w-3.5 h-3.5" />
                    </button>
                    <button
                      onClick={() => handleDelete(item)}
                      className="w-7 h-7 rounded-full bg-black/60 flex items-center justify-center text-red-400 hover:bg-red-500/20"
                      title="Delete"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                )}
              </div>
            ))}
          </div>
        )}
      </div>
      <UsernamePrompt />
    </div>
  );
}